const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors({
    origin: '*'
}));
const bodyParser = require('body-parser')



app.get('/', function (req, res) {
   res.send('Up and Running!!');
})

app.get('/health', function (req, res) {
    res.send('Health Check! Up and Running!!');
 })

const apiRoute = require('./src/routes/routes')

app.use(bodyParser.json())
app.use('/inc/api/',apiRoute)

var server = app.listen(8085, function () {
   var host = server.address().address
   var port = server.address().port   
   console.log("Example app listening at http://%s:%s", host, port)
})