var UserService = require("../services/UserService");
var eutil = require("../common/eutil");
let { StatusCodes } = require("http-status-codes");

exports.addUser = async (req, res) => {
  try {
    eutil.log("UserController:addUser starts ");
    let result = [];
    result = await UserService.addUser(req, res);
    eutil.log("UserController:addCompany ends ");
    res.send(result).status(StatusCodes.ACCEPTED);
  } catch (e) {
    eutil.logError("Error in UserController:addUser " + e);
    res
      .status(StatusCodes.INTERNAL_SERVER_ERROR)
      .send(eutil.getErrorResponse());
  }
};

// exports.updateCompany = async (req, res) => {
//   try {
//     eutil.log("companyController:updateCompany starts ");
//     let result = [];
//     result = await companyService.updateCompany(req, res);
//     eutil.log("companyController:updateCompany ends ");
//     res.send(result).status(StatusCodes.ACCEPTED);
//   } catch (e) {
//     eutil.logError("Error in companyController:updateCompany " + e);
//     res
//       .status(StatusCodes.INTERNAL_SERVER_ERROR)
//       .send(eutil.getErrorResponse());
//   }
// };

// exports.getCompany = async (req, res) => {
//   try {
//     eutil.log("companyController:getCompany starts ");
//     let qryParams = req.query;
//     let result = [];
//     if (qryParams && qryParams.incId && qryParams.incId > 0) {
//       result = await companyService.getCompanyByIncubationId(qryParams.incId);
//     } else if (qryParams && qryParams.companyId && qryParams.companyId > 0) {
//       result = await companyService.getCompanyId(qryParams.companyId);
//     } else if (qryParams && qryParams.email && qryParams.email != "") {
//       result = await companyService.getCompanyByEmail(qryParams.email);
//     } else {
//       let resp = eutil.getErrorResponse();
//       resp.message = "Either companyId or incubatorId is Mandatory";
//       res.status(StatusCodes.EXPECTATION_FAILED).send(resp);
//     }

//     eutil.log("companyController:getCompany ends ");
//     res.send(result).status(StatusCodes.ACCEPTED);
//   } catch (e) {
//     eutil.logError("Error in companyController:getCompany " + e);
//     res
//       .status(StatusCodes.INTERNAL_SERVER_ERROR)
//       .send(eutil.getErrorResponse());
//   }
// };

// exports.getCompanyContact = async (req, res) => {
//     try {
//       eutil.log("companyController:getCompanyContact starts ");
//       let qryParams = req.query;
//       let result = [];
//       if (qryParams && qryParams.companyId && qryParams.companyId > 0) {
//         result = await companyService.getCompanyContact(qryParams.companyId);
//       }  else {
//         let resp = eutil.getErrorResponse();
//         resp.message = "companyId is Mandatory";
//         res.status(StatusCodes.EXPECTATION_FAILED).send(resp);
//       }
  
//       eutil.log("companyController:getCompanyContact ends ");
//       res.send(result).status(StatusCodes.ACCEPTED);
//     } catch (e) {
//       eutil.logError("Error in companyController:getCompanyContact " + e);
//       res
//         .status(StatusCodes.INTERNAL_SERVER_ERROR)
//         .send(eutil.getErrorResponse());
//     }
//   };

// exports.getAllCompany = async (req, res) => {
//   try {
//     eutil.log("companyController:getAllCompany starts ");
//     result = await companyService.getCompany();
//     eutil.log("companyController:getAllCompany ends ");
//     res.send(result).status(StatusCodes.ACCEPTED);
//   } catch (e) {
//     eutil.logError("Error in companyController:getAllCompany " + e);
//     res
//       .status(StatusCodes.INTERNAL_SERVER_ERROR)
//       .send(eutil.getErrorResponse());
//   }
// };

// exports.deleteCompany = async (req, res) => {
//   try {
//     eutil.log("companyController:deleteCompany starts ");
//     let qryParams = req.query;
//     let result = [];
//     if (qryParams && qryParams.companyId && qryParams.companyId > 0) {
//       result = await companyService.deleteCompany(qryParams.companyId);
//       eutil.log("companyController:deleteCompany ends ");
//       res.send(result).status(StatusCodes.ACCEPTED);
//     } else {
//       let resp = eutil.getErrorResponse();
//       resp.message = errors;
//       res.status(StatusCodes.EXPECTATION_FAILED).send(resp);
//     }
//   } catch (e) {
//     eutil.logError("Error in companyController:deleteCompany " + e);
//     res
//       .status(StatusCodes.INTERNAL_SERVER_ERROR)
//       .send(eutil.getErrorResponse());
//   }
// };
