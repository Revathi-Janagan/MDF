'use strict'

var dbutl = require('../common/dbUtils');
var eutil = require('../common/eutil')


exports.add = async (user) => {
    

    var dbData = prepareCompanyDbData(user)
    eutil.log("UserDAO:add:starts")
    var sql = "insert into company set ? ";
    var userRes = await dbutl.executeUpdateNeat(sql, dbData)
    eutil.log("UserDAO:add:ends")
    return userRes

}