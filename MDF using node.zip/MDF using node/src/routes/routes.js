const express = require('express')

const route = express.Router();

const UserController = require('../controller/UserController')

route.get('/user', UserController.getUser)
route.get('/user/all', UserController.getAllUser)
route.post('/user', UserController.addUser)
route.put('/user', UserController.updateUser)
route.delete('/user', UserController.deleteUser)