var UserDAO = require('../dao/UserDAO');
var eutil = require('../common/eutil')
let { StatusCodes } = require('http-status-codes')


exports.addUser = async (req, res) => {
    let user = req.body
   
    let result = {}

    eutil.log("UserService:addUser starts ")
    let errors = []
    if (validateUser(user, 'add', errors)) {
        result = await UserDAO.add(user)
    } else {
        let resp = eutil.getErrorResponse()
        resp.message = errors
        res.status(StatusCodes.EXPECTATION_FAILED).send(resp)
    }
    eutil.log("UserService:addUser ends")
    return result;
}